package net.sourceforge.MinhchienbaseOnVietOcr;

import net.Mchien.NhanDangCongVanOcr.Gui;
import net.Mchien.NhanDangCongVanOcr.OCRHelper;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import net.Mchien.NhanDangCongVan.util.Utils;


public class OCRHelperTest {

    static final boolean WINDOWS = System.getProperty("os.name").toLowerCase().startsWith("windows");
    String tessPath;

    public OCRHelperTest() {
        tessPath = WINDOWS ? new File(System.getProperty("user.dir"), Gui.TESSERACT_PATH).getPath() : "/usr/bin";
    }


    public static void setUpClass() {
    }


    public static void tearDownClass() {
    }


    public void setUp() {
    }

  
    public void tearDown() {
    }

    /**
     * Test of performOCR method, of class OCRHelper.
     */

    public void testPerformOCR() throws Exception {
        System.out.println("performOCR");
        String langCode = "vie";
        String pageSegMode = "3";
        String outputFormat = "text";
        String inputFolder = "samples";
        String outputFolder = "build/test/results";
        List<File> files = new ArrayList<File>();
        Utils.listImageFiles(files, new File(inputFolder));

        for (File imageFile : files) {
            try {
                System.out.println("Process " + imageFile.getPath());
                String outputFilename = imageFile.getPath().substring(inputFolder.length() + 1);
                OCRHelper.performOCR(imageFile, new File(outputFolder, outputFilename), tessPath, langCode, pageSegMode, outputFormat, false);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

       ;
    }
}
