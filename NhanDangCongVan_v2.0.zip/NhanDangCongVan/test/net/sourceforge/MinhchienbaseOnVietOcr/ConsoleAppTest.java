package net.sourceforge.MinhchienbaseOnVietOcr;

import net.Mchien.NhanDangCongVanOcr.ConsoleApp;
import java.io.File;


public class ConsoleAppTest {
    
    public ConsoleAppTest() {
    }
    
  
    public static void setUpClass() {
    }
    
 
    public static void tearDownClass() {
    }
    
  
    public void setUp() {
    }

    public void tearDown() {
    }

    /**
     * Test of main method, of class ConsoleApp.
     */

    public void testMain() {
        System.out.println("main");
        String outfile = "build/test/results/out";
        String[] args = {"samples/vietsample.tif", outfile, "-l", "vie", "hocr"};
        ConsoleApp.main(args);
       
    }
    
}
