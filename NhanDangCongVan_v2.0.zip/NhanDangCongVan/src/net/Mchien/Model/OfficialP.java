/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.Mchien.Model;

/**
 *
 * @author angel
 */
public class OfficialP {
   int id;
   String ToDo,NSend,NumberSend,Recived,Contents,NRecived,Place;

  
   String OrImage,OrSpan;
      public OfficialP() {
    }

    public OfficialP(int id,String NSend, String ToDo,  String NumberSend,String Place, String Recived, String Contents, String NRecived, String OrImage, String OrSpan) {
        this.id = id;
        this.ToDo = ToDo;
        this.NSend = NSend;
        this.Place = Place;
        this.NumberSend = NumberSend;
        this.Recived = Recived;
        this.Contents = Contents;
        this.NRecived = NRecived;
        this.OrImage = OrImage;
        this.OrSpan = OrSpan;
    }
    public void setPlace(String Place) {
        this.Place = Place;
    }

    public String getPlace() {
        return Place;
    }
    public int getId() {
        return id;
    }

    public String getToDo() {
        return ToDo;
    }

    public String getNSend() {
        return NSend;
    }

    public String getNumberSend() {
        return NumberSend;
    }

    public String getRecived() {
        return Recived;
    }

    public String getContents() {
        return Contents;
    }

    public String getNRecived() {
        return NRecived;
    }

    public String getOrImage() {
        return OrImage;
    }

    public String getOrSpan() {
        return OrSpan;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setToDo(String ToDo) {
        this.ToDo = ToDo;
    }

    public void setNSend(String NSend) {
        this.NSend = NSend;
    }

    public void setNumberSend(String NumberSend) {
        this.NumberSend = NumberSend;
    }

    public void setRecived(String Recived) {
        this.Recived = Recived;
    }

    public void setContents(String Contents) {
        this.Contents = Contents;
    }

    public void setNRecived(String NRecived) {
        this.NRecived = NRecived;
    }

    public void setOrImage(String OrImage) {
        this.OrImage = OrImage;
    }

    public void setOrSpan(String OrSpan) {
        this.OrSpan = OrSpan;
    }
      
}
