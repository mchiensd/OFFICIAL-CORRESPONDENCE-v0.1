/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.Mchien.ConnectSQL;
import java.sql.*;
import java.util.ArrayList;
import net.Mchien.Model.OfficialP;
/**
 *
 * @author angel
 */
public class ConnectSQL {
     String connectionUrl = "jdbc:sqlserver://localhost:1433;" +  
         "databaseName=NhanDangCongVan;integratedSecurity=true;"; 
      Connection con = null;  
      Statement stmt = null;  
      ResultSet rs = null; 
      ArrayList<OfficialP> listcv = new ArrayList<OfficialP>();
      public ArrayList<OfficialP> GetDataBase(){
            try {  
         // Establish the connection.  
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
         con = DriverManager.getConnection(connectionUrl);  

         // Create and execute an SQL statement that returns some data.  
         String SQL = "SELECT * FROM OFFICIAL_CORRESPONDENCE";  
         stmt = con.createStatement();  
         rs = stmt.executeQuery(SQL);  
         
         // Iterate through the data in the result set and display it.  
         while (rs.next()) {  
             OfficialP a = new OfficialP(rs.getInt(1), rs.getString(3), rs.getString(2), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8),rs.getString(9),rs.getString(10));
             listcv.add(a);
         } 
         return listcv;
      }  

      // Handle any errors that may have occurred.  
      catch (Exception e) {  
         e.printStackTrace();  
      }  
      finally {  
         if (rs != null) try { rs.close(); } catch(Exception e) {}  
         if (stmt != null) try { stmt.close(); } catch(Exception e) {}  
         if (con != null) try { con.close(); } catch(Exception e) {}  
      }  
            return null;
      }
      
      
      
      
      
      
      
      
       public boolean  AddDataBase(String sql){
            try {  
         // Establish the connection.  
         Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
         con = DriverManager.getConnection(connectionUrl);  
         PreparedStatement pstmt = con.prepareStatement(sql);
        // pstmt.setBytes(1, array);
         // Iterate through the data in the result set and display it.  
        if ( pstmt.executeUpdate()>0){
            return true;
        }
        return false;
      }  

      // Handle any errors that may have occurred.  
      catch (Exception e) {  
         e.printStackTrace();  
      }  
      finally {  
         if (rs != null) try { rs.close(); } catch(Exception e) {}  
         if (stmt != null) try { stmt.close(); } catch(Exception e) {}  
         if (con != null) try { con.close(); } catch(Exception e) {}  
      }  
            return false;
      }
}
